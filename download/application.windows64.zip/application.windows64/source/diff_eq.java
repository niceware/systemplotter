import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class diff_eq extends PApplet {

Grid grid;
ArrayList<Point> points = new ArrayList<Point>();
ClickBox steps, drag;
StepBox conti, rando, placer;
TextBox coBox[], stsiBox, rCountBox, placeBox[];
HyperLink name;

final int VG = 500, HG = 500;
final PVector eqUIpos = new PVector(40, 45);
int bg, gridlines, midgrid;
float coVal[], stepSize;
int mousX, mousY, spaceUI, rCount, placePos[];


public void setup() {
  
  frameRate(60);
  colorMode(HSB, 180, 100, 100, 100);
  ellipseMode(CENTER);

  setVars();
}

public void draw() {
  background(bg);

  varStep();
  showPoints();
  cleanUp();
  showUI();
  //forScreens();

  println(frameRate);
}

public void mouseDragged() {
  if (drag.ticked) {
    if (grid.get(mousX, mousY) != null) points.add(new Point(grid, mousX, mousY, (int)(3/stepSize)));
  }
}

public void mouseClicked() {
  if (!drag.ticked) {
    if (grid.get(mousX, mousY) != null) points.add(new Point(grid, mousX, mousY, (int)(3/stepSize)));
  }
}

public void setVars() {
  mousX = 0;
  mousY = 0;
  spaceUI = 200;
  placePos = new int[2];
  stepSize = .1f;
  coVal = new float[4];
  for (int i = 0; i < coVal.length; i++) coVal[i] = 1;

  bg = color(0xffdddddd);
  gridlines = color(0xff999999);
  midgrid = color(0xff555555);

  grid = new Grid(VG, HG, spaceUI, bg, gridlines, midgrid);
  steps = new ClickBox(eqUIpos.x-24, eqUIpos.y+70);
  drag = new ClickBox(eqUIpos.x-24, eqUIpos.y+85);
  conti = new StepBox(eqUIpos.x+50, eqUIpos.y+70, 14, 10, true);
  rando = new StepBox(eqUIpos.x-24, eqUIpos.y+105);
  placer = new StepBox(eqUIpos.x-24, eqUIpos.y+125);
  coBox = new TextBox[4];
  coBox[0] = new TextBox(eqUIpos.x, eqUIpos.y);
  coBox[1] = new TextBox(eqUIpos.x+50, eqUIpos.y);
  coBox[2] = new TextBox(eqUIpos.x, eqUIpos.y+20);
  coBox[3] = new TextBox(eqUIpos.x+50, eqUIpos.y+20);
  placeBox = new TextBox[2];
  placeBox[0] = new TextBox(eqUIpos.x+72, eqUIpos.y+120);
  placeBox[1] = new TextBox(eqUIpos.x+112, eqUIpos.y+120);
  stsiBox = new TextBox(eqUIpos.x+35, eqUIpos.y+40);
  stsiBox.value = Float.toString(stepSize);
  rCountBox = new TextBox(eqUIpos.x+24, eqUIpos.y+100);
  name = new HyperLink("brianna reilly", "https://niceware.github.io/systemplotter", 120, height-12);
}

public void varStep() {
  mousX = (int)map(mouseX, spaceUI, width, -VG/2, VG/2);
  mousY = (int)map(mouseY, 0, height, HG/2, -HG/2);

  if ((millis() % 100 < 15 && steps.ticked) || conti.ticked) {
    for (int i = 0; i < points.size(); i++) {
      Point temp = points.get(i);
      temp.d.x = getD(temp.truePos.x, temp.truePos.y, true);
      temp.d.y = getD(temp.truePos.x, temp.truePos.y, false);
      temp.incre(temp.d.x, temp.d.y);
      temp.update();
    }
    conti.endStep();
  }
  if (rando.ticked) {
    for (int i = 0; i < rCount; i++) points.add(new Point(grid, (int)random(-VG/2, VG/2), (int)random(-HG/2, HG/2), (int)(3/stepSize)));
    rando.endStep();
  }
  if (placer.ticked) {
    points.add(new Point(grid, placePos[0], placePos[1], (int)(3/stepSize)));
    placer.endStep();
  }
}

public void showPoints() {
  grid.display();
  for (Point p : points) {
    p.display();
  }
}

public void cleanUp() {
  for (int i = points.size()-1; i >= 0; i--) {
    int teml = points.get(i).prev.length-1;
    PVector temm[] = {points.get(i).pos, points.get(i).prev[teml/4], points.get(i).prev[teml/2], points.get(i).prev[teml*3/4], points.get(i).prev[teml]};
    if (temm[0] == null && temm[1] == null && temm[2] == null && temm[3] == null && temm[4] == null) points.remove(i);
  }
}

public void showUI() {
  fill(0xff000000);
  text("mouse "+((mousX > -VG/2)?("@ "+mousX+", "+mousY):"not on graph"), 10, 20);
  text(points.size()+" points being tracked", 10, 32);
  
  for (int i = 0; i < coBox.length; i++) {
    coBox[i].display();
    coVal[i] = coBox[i].getNum();
    if (i < placeBox.length) {
      placeBox[i].display();
      placePos[i] = (int)placeBox[i].getNum();
    }
  }
  stsiBox.display();
  stepSize = stsiBox.getNum();
  rCountBox.display();
  rCount = (int)rCountBox.getNum();
  steps.display();
  drag.display();
  conti.display();
  rando.display();
  placer.display();
  fill(0xff000000);
  text("x' =           x +          y", eqUIpos.x-24, eqUIpos.y+13);
  text("y' =           x +          y", eqUIpos.x-24, eqUIpos.y+33);
  text("step size:", eqUIpos.x-20, eqUIpos.y+54);
  text("auto-step", eqUIpos.x-9, eqUIpos.y+79);
  text("drag to place", eqUIpos.x-9, eqUIpos.y+94);
  text("place           random point"+((rCount > 1)?"s":""), eqUIpos.x-9, eqUIpos.y+114);
  text("place point at (         ,           )", eqUIpos.x-9, eqUIpos.y+134);
  
  text("systems of equations plotter", 40, height-24);
  text("by", 104, height-12);
  name.display();
}

public float getD(float x, float y, boolean isX) {
  if (isX) return ((coVal[0] * x) + (coVal[1] * y)) * stepSize;
  else return ((coVal[2] * x) + (coVal[3] * y)) * stepSize;
}

public void forScreens() {
  if (key == 'p') {
    saveFrame("scr/scr-######.png");
  }
}
class ClickBox {
  PVector pos;
  float boxWid, boxHei;
  boolean clicked, stillClicked, ticked;
  
  ClickBox() {
    this(10, 10);
  }
  ClickBox(float x, float y) {
    this(x, y, 10, 10);
  }
  ClickBox(float x, float y, float w, float h) {
    pos = new PVector(x, y);
    boxWid = w;
    boxHei = h;
    
    clicked = false;
    stillClicked = false;
    ticked = false;
  }
  
  public void display() {
    checkClicked();
    stroke(0xff000000);
    fill(0xffffffff);
    rect(pos.x, pos.y, boxWid, boxHei);
    if (ticked) {
      stroke(0xff445544);
      line(pos.x+(boxWid/4), pos.y+(boxHei/2), pos.x+(boxWid/2), pos.y+boxHei);
      line(pos.x+(boxWid/2), pos.y+boxHei, pos.x+boxWid+2, pos.y-2);
    }
  }
  
  public void checkClicked() {
      if (mouseX > pos.x && mouseX < pos.x+boxWid && mouseY > pos.y && mouseY < pos.y+boxHei && mousePressed) clicked = true;
      else clicked = false;
    if (clicked && !stillClicked) {
      ticked = !ticked;
      stillClicked = true;
    } else if (!clicked && stillClicked) stillClicked = false;
  }
}
class Grid {
  int vert, horiz, disp;
  float wid, hei;
  int defaults[];
  PVector pos[][], scale;

  Grid() {
    this(10, 10, 200);
  }
  Grid(int v, int h, int d) {
    this(v, h, d, color(0xffbbbbbb), color(0xff555555), color(0xff880000));
  }
  Grid(int v, int h, int d, int c1, int c2, int c3) {
    vert = v;
    horiz = h;
    disp = d;
    wid = width - disp - 1;
    hei = height - 1;
    scale = new PVector(vert/50, horiz/50);;

    defaults = new int[3];
    defaults[0] = c1;
    defaults[1] = c2;
    defaults[2] = c3;

    pos = new PVector[vert+1][horiz+1];
    for (int i = 0; i <= vert; i++) {
      for (int j = 0; j <= horiz; j++) {
        pos[i][j] = new PVector(disp+(wid*i)/vert, (hei*j)/horiz);
      }
    }
  }

  public void display() {
    stroke(defaults[1]);
    for (int i = 0; i <= vert; i+=scale.x) 
      line(disp+(wid*i)/vert, 0, disp+(wid*i)/vert, hei);
    for (int i = 0; i <= horiz; i+=scale.y) 
      line(disp, (hei*i)/horiz, disp+wid, (hei*i)/horiz);

    stroke(defaults[2]);
    line(disp, hei/2, disp+wid, hei/2);
    line(disp+wid/2, 0, disp+wid/2, hei);
  }
  
  public float get(int x, int y, boolean ifX) {
    int newx = (vert/2) + x;
    int newy = (horiz/2) - y;
    
    if (ifX) return pos[newx][newy].x;
    else return pos[newx][newy].y;
  }
  
  public PVector get(int x, int y) {
    int newx = (vert/2) + x;
    int newy = (horiz/2) - y;
    //if (newx > vert) newx = vert;
    //if (newy > horiz) newy = horiz;
    //if (newx < 0) newx = 0;
    //if (newy < 0) newy = 0;
    if (newx > vert || newx < 0 || newy > horiz || newy < 0) return null;
    
    return pos[newx][newy];
  }
}
class HyperLink {
  PVector pos;
  int unclicked, clicked, old;
  String displayText, uRL;
  float texWid, texHei;
  private int timeDown;
  boolean once;

  HyperLink(String d, String u) {
    this(d, u, 10, 10);
  }
  HyperLink(String d, String u, float x, float y) {
    pos = new PVector(x, y);
    displayText = d;
    uRL = u;

    unclicked = 0xff0000ee;
    clicked = 0xffee0000;
    old = 0xff551a8b;
    timeDown = 0;
    texWid = textWidth(displayText)*5/6;
    texHei = 8;
    once = false;
  }

  public void display() {
    checkClicked();
    fill(pickColor());
    text(displayText, pos.x, pos.y);
    stroke(pickColor());
    line(pos.x, pos.y+1, pos.x+texWid, pos.y+1);

    timeDown--;
  }

  public void checkClicked() {
    if (mouseX > pos.x && mouseX < pos.x+texWid && mouseY > pos.y-texHei && mouseY < pos.y) {
    cursor(HAND);
      if (mousePressed && timeDown <= 0) {
        link(uRL);
        once = true;
        timeDown = 10;
      }
    } else cursor(ARROW);
  }

  public int pickColor() {
    if (timeDown > 0) return clicked;
    else if (once) return old;
    else return unclicked;
  }
}

class Point {
  Grid base;
  PVector truePos, pos, prev[], d;
  int fill, outline;
  int rad;
  private boolean trailing;

  Point(Grid g) {
    this(g, 0, 0);
  }
  Point(Grid g, PVector p) {
    this(g, p.x, p.y);
  }
  Point(Grid g, float x, float y) {
    this(g, x, y, 0);
  }
  Point(Grid g, PVector p, int prv) {
    this(g, p.x, p.y, prv);
  }
  Point(Grid g, float x, float y, int prv) {
    rad = 8;
    truePos = new PVector(x, y);
    fill = color(random(180), 70, 100);
    outline = color(hue(fill), 100, 70);

    if (prv > 0) {
      trailing = true;
      prev = new PVector[prv];
      for (int i = 0; i < prev.length; i++) {
        prev[i] = pos;
      }
    } else trailing = false;

    base = g;
    pos = base.get((int)x, (int)y);
    d = new PVector(1, 1);
  }

  public void update() {
    if (trailing) {
      for (int i = prev.length-1; i > 0; i--) {
        prev[i] = prev[i-1];
      }
      if (pos != null) prev[0] = new PVector(pos.x, pos.y);
      else prev[0] = null;
    }
  }

  public void display() {
    if (trailing) {
      for (int i = prev.length-1; i > 0; i--) {
        int tempOut = color(hue(outline), saturation(outline), brightness(outline), map(i, 0, prev.length, 100, 0));
        stroke(tempOut);
        if (prev[i] != null && prev[i-1] != null) line(prev[i].x, prev[i].y, prev[i-1].x, prev[i-1].y); 
      }
    }
    fill(fill);
    stroke(outline);
    if (pos != null) ellipse(pos.x, pos.y, rad, rad);
  }

  public void incre(float xx, float yy) {
    truePos.add(xx, yy);
    pos = base.get((int)truePos.x, (int)truePos.y);
  }

  public boolean isTrailing() {
    return trailing;
  }
}
class StepBox extends ClickBox {
  boolean arrows;
  StepBox() {
    this(10, 10);
  }
  StepBox(float x, float y) {
    this(x, y, 10, 10, false);
  }
  StepBox(float x, float y, float w, float h, boolean a) {
    pos = new PVector(x, y);
    boxWid = w;
    boxHei = h;

    arrows = a;
    clicked = false;
    stillClicked = false;
    ticked = false;
  }

  public void display() {
    checkClicked();
    stroke(0xff000000);

    if (ticked) fill(0xffaaffaa);
    else fill(0xffffffff);
    rect(pos.x, pos.y, boxWid, boxHei);
    if (arrows) {
      line(pos.x+(boxWid/4), pos.y, pos.x+(boxWid/2), pos.y+(boxHei/2));
      line(pos.x+(boxWid/2), pos.y+(boxHei/2), pos.x+(boxWid/4), pos.y+boxHei);
      line(pos.x+(boxWid/2), pos.y, pos.x+(boxWid*3/4), pos.y+(boxHei/2));
      line(pos.x+(boxWid*3/4), pos.y+(boxHei/2), pos.x+(boxWid/2), pos.y+boxHei);
    }
  }

  public void endStep() {
    if (ticked) ticked = false;
  }
}

class TextBox extends ClickBox {
  String value;
  float numVal;
  char lastCh;
  boolean clear;

  TextBox() {
    this(10, 10);
  }
  TextBox(float x, float y) {
    pos = new PVector(x, y);

    clear = false;
    boxWid = 26;
    boxHei = 16;
    lastCh = ' ';
    value = "1";
  }

  public void display() {
    checkClicked();
    type();
    stroke(0xff000000);
    if (clicked) fill(0xffeeeeee);
    else fill(0xffffffff);
    rect(pos.x, pos.y, boxWid, boxHei);
    String tempStr = "";
    if (value.length() > 3) tempStr = value.substring(value.length()-3, value.length());
    else tempStr = value;
    fill(0xff000000);
    text(tempStr, pos.x+4, pos.y+13);
  }
  
  public void checkClicked() {
    if (mousePressed) {
      if (mouseX > pos.x && mouseX < pos.x+boxWid && mouseY > pos.y && mouseY < pos.y+boxHei) clicked = true;
      else clicked = false;
    }
  }

  public void type() {
    if (clicked) {
      if (!clear) {
        if (key != 8 && key != 9 && key != 10 && key != 32) { //tab, space, enter
          if (keyPressed && lastCh != key) {
            value += key;
            lastCh = key;
          }
        } else clear = true;
      } else {
        value = "";
        lastCh = ' ';
        clear = false;
      }
    } else lastCh = ' ';
  }

  public float getNum() {
    try {
      if (value.length() > 3) numVal =  Float.parseFloat(value.substring(value.length()-3, value.length()));
      else numVal = Float.parseFloat(value);
    } catch (NumberFormatException e) {}
    return numVal;
  }
}
/**
 * hey! thanks for uh. looking at this I guess
 *
 * feel free to use any of this in your own projects, 
 * whether you base something on this or just use nab
 * of the classes. credit would be nice, though, so 
 * somewhere in your documentation just mention it.
 * or maybe leave a comment at the top of the code if
 * you use one of the classes. 
 *
 * think something could be better? let me know!
 */
  public void settings() {  size(600, 400); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "diff_eq" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
